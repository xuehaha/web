var mysql = require('mysql')
var express = require('express')
var app = express()
var bodyParser = require('body-parser')
var async = require('async')
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

//跨域支持
app.all('*', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*')
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS')
  res.header('Access-Control-Allow-Headers', 'X-Requested-With')
  res.header('Access-Control-Allow-Headers', 'Content-Type')
  next()
})
var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'zxc123',
  database: 'music'
})

app.get('/', function(req, res) {
  res.send('hello')
})
// 登录接口
app.post('/login', function(req, res) {
  var username = req.body.data.username
  var password = req.body.data.password
  connection.connect()
  var sql = `SELECT * FROM user where username="${username}" and password="${password}"`
  connection.query(sql, function(err, result) {
    console.log(err)
    if (err) {
      res.send({ code: -1, msg: '登录失败' })
    } else {
      console.log(result)
      if (result.length == 0) {
        res.send({ code: 1, msg: '用户名或者密码错误' })
      } else {
        res.send({ code: 200, msg: '登录成功', username: username })
      }
    }
  })
})

// 注册接口
app.post('/register', function(req, res) {
  var username = req.body.data.username
  var password = req.body.data.password
  connection.connect()
  // var  sql = `insert into userInfo (username,password) VALUES(${username},${password})`;
  var sql = `SELECT * FROM userInfo where username="${username}"`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({ code: -1, msg: '查询数据库失败' })
    } else {
      if (result.length > 0) {
        res.send({ code: 1, msg: '用户名已存在' })
      } else {
        var sql1 = `insert into userInfo (username,password) VALUES("${username}","${password}")`
        connection.query(sql1, function(err, result) {
          if (err) {
            res.send({ code: -1, msg: '插入失败' })
          } else {
            res.send({ code: 2, msg: '插入成功', username: username })
          }
        })
      }
    }
  })
})

//推介列表接口
app.get('/recommend', function(req, res) {
  connection.connect()
  var sql = 'SELECT * FROM recommend'
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      // console.log(result)
      res.send({
        code: 200,
        data: result
      })
    }
  })
})
//排行榜列表接口
app.get('/ranking', function(req, res) {
  connection.connect()
  var sql = 'SELECT * FROM ranking'
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      // console.log(result)
      res.send({
        code: 200,
        data: result
      })
    }
  })
})
//查询歌曲列表接口

app.get('/searsch', function(req, res) {
  var pageSize = parseInt(req.query.pageSize)
  let page = 10
  let startPage = (pageSize - 1) * page
  let endPage = page
  var textVal = req.query.inputText
  connection.connect()
  async.parallel(
    [
      function(callback) {
        var sql = `SELECT * FROM musiclist where singer like '%${textVal}%' limit ${startPage},${endPage}`
        connection.query(sql, function(err, result) {
          if (err) {
            callback({ code: -1001, msg: '查询数据库失败' })
          } else {
            callback(null, result)
          }
        })
      },
      function(callback) {
        var sql = `SELECT COUNT(*) as count FROM musiclist where singer like '%${textVal}%' `
        connection.query(sql, function(err, result) {
          if (err) {
            callback({ code: -1001, msg: '查询数据库失败' })
          } else {
            callback(null, result[0].count)
          }
        })
      }
    ],
    function(err, result) {
      if (err) {
        console.log(err)
      } else {
        if (Math.ceil(result[1] / page) < pageSize) {
          res.send({
            code: -1002,
            message: '暂无更多数据'
          })
        } else {
          res.send({
            code: 200,
            data: result[0],
            count: result[1]
          })
        }
      }
    }
  )
})

//歌曲播放列表接口
app.get('/playlist', function(req, res) {
  var valId = req.query.valId
  console.log(valId)
  connection.connect()
  var sql = `SELECT * FROM playlist WHERE id=${valId}`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      if (result.length < 1) {
        res.send({
          code: -1002,
          message: '暂无更多数据'
        })
      } else {
        res.send({
          code: 200,
          data: result
        })
      }
    }
  })
})

//歌曲收藏接口
app.get('/collect', function(req, res) {
  var valId = req.query.valId
  console.log(valId)
  connection.connect()
  var sql = `SELECT * FROM playlist WHERE id=${valId}`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      if (result.length < 1) {
        res.send({
          code: -1002,
          message: '暂无更多数据'
        })
      } else {
        res.send({
          code: 200,
          data: result
        })
      }
    }
  })
})

app.listen(3000, () => {
  console.log('success', function() {
    console.log('服务器启动成功,且地址是', 'http://localhost:3000')
  })
})
