const express = require('express')
const app = express()
const mysql = require('mysql')
const bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

//跨域支持
app.all('*', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*')
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS')
  res.header('Access-Control-Allow-Headers', 'X-Requested-With')
  res.header('Access-Control-Allow-Headers', 'Content-Type')
  next()
})

var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'zhaopin',
  multipleStatements: true
})
connection.connect()

app.get('/', function(req, res) {
  res.send('hello')
})

//登录接口
app.post('/login', function(req, res) {
  var username = req.body.username
  var password = req.body.password
  var sql = `SELECT * FROM users where username='${username}' and password='${password}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1,
        msg: '登录失败'
      })
    } else {
      if (result.length == 0) {
        res.send({
          code: 1,
          msg: '用户名或密码错误'
        })
      } else {
        res.send({
          code: 200,
          msg: '登录成功',
          result
        })
      }
    }
  })
})

// 注册接口
app.post('/register', function(req, res) {
  var username = req.body.username
  var password = req.body.password
  var identity = req.body.identity
  var sql = `SELECT * FROM users where username='${username}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({ code: -1, msg: '查询数据库失败' })
    } else {
      if (result.length > 0) {
        res.send({ code: 1, msg: '用户名已存在' })
      } else {
        var sql1 = `insert into users (username, password, identity) VALUES ('${username}', '${password}', '${identity}')`
        connection.query(sql1, function(err, result) {
          if (err) {
            res.send({ code: -1, msg: '注册失败' })
          } else {
            res.send({ code: 2, msg: '注册成功' })
          }
        })
      }
    }
  })
})

// 修改密码接口
app.post('/updatePass', function(req, res) {
  var username = req.body.username
  var password = req.body.password
  var sql = `update users set password='${password}' where username='${username}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({ code: -1, msg: '查询数据库失败' })
    } else {
      if (result) {
        res.send({ code: 2, msg: '密码修改成功' })
      } else {
        res.send({ code: -1, msg: '密码修改失败' })
      }
    }
  })
})

// 个人资料渲染接口
app.get('/personal', function(req, res) {
  var id = req.query.id
  var sql = `select username, nickname, phone, email from users where id='${id}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 200,
        data: result
      })
    }
  })
})

// 修改个人资料接口
app.post('/updateInfo', function(req, res) {
  var id = req.body.id
  var nickname = req.body.nickname
  var phone = req.body.phone
  var email = req.body.email
  var sql = `
  update users set nickname='${nickname}', phone='${phone}', 
  email='${email}' where id='${id}'
  `
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({ code: -1, msg: '查询数据库失败' })
    } else {
      res.send({
        code: 2,
        msg: '修改成功'
      })
    }
  })
})

// 首页渲染接口
app.get('/index', function(req, res) {
  var sql = `SELECT * FROM jobclass`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 200,
        data: result
      })
    }
  })
})

// company页渲染接口
app.get('/company', function(req, res) {
  var sql = `SELECT * FROM companylist`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 200,
        data: result
      })
    }
  })
})

// post页渲染接口
app.get('/post', function(req, res) {
  var sql = `select companylist.comname, companylist.comtype, postlist.id, postlist.posname, postlist.pospay, postlist.posregion, postlist.poseducation, users.nickname from postlist left join companylist on postlist.user_id=companylist.user_id left join users on postlist.user_id=users.id `
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 200,
        data: result
      })
    }
  })
})

// job_detail 详情页渲染接口
app.get('/job_detail', function(req, res) {
  // res.send({ id: req.query.id })
  var id = req.query.id
  var sql = `
    select * from postlist where id='${id}'
  `
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      var id = req.query.id
      var companyId = result[0].company_id
      var userId = result[0].user_id
      var sql1 = `
      select * from postlist where id='${id}';
      select * from companylist where id='${companyId}';
      select * from postdetail where post_id='${id}';
      select nickname from users where id='${userId}'
      `
      connection.query(sql1, function(err, result) {
        if (err) {
          res.send({
            code: -1002,
            msg: '查询数据库失败',
            err: err
          })
        } else {
          res.send({
            code: 200,
            data: result
          })
        }
      })
    }
  })
})

// company_detail 详情页渲染接口
app.get('/company_detail', function(req, res) {
  // res.send({ id: req.query.id })
  var id = req.query.id
  var sql = `
    select * from companylist where id='${id}';
    select * from postlist where company_id='${id}';
    select * from companydetail where company_id='${id}';
  `
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 200,
        data: result
      })
    }
  })
})

// 职位搜索查询接口
app.get('/search', function(req, res) {
  var value = req.query.value
  var sql = `
  select companylist.comname, companylist.comtype, postlist.id, 
  postlist.posname, postlist.pospay, postlist.posregion, postlist.poseducation,
  users.nickname from postlist left join companylist on postlist.user_id=companylist.user_id 
  left join users on postlist.user_id=users.id 
  where posname like '%${value}%'
  `
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 200,
        data: result
      })
    }
  })
})

// 简历渲染接口
app.get('/resume', function(req, res) {
  var userId = req.query.id
  var sql = `select * from resume where user_id='${userId}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 200,
        data: result
      })
    }
  })
})

// 修改简历接口
app.post('/updateResume', function(req, res) {
  var id = req.body.id
  var user_id = req.body.user_id
  var xingming = req.body.xingming
  var xueli = req.body.xueli
  var zhiwei = req.body.zhiwei
  var jianjie = req.body.jianjie
  console.log(req.body)

  var sql = `update resume set xingming='${xingming}', xueli='${xueli}', zhiwei='${zhiwei}', jianjie='${jianjie}' where user_id='${id}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({ code: -1, msg: '查询数据库失败' })
    } else {
      res.send({
        code: 2,
        msg: '修改成功'
      })
    }
  })
})

// 发布求职渲染接口
app.get('/publish', function(req, res) {
  var userId = req.query.id
  var sql = `select * from postlist where user_id='${userId}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      var sql1 = `select postlist.*, postdetail.posttxt from postlist join postdetail on postlist.id=postdetail.post_id where postlist.user_id='${userId}'`
      connection.query(sql1, function(err, result) {
        if (err) {
          res.send({
            code: -1001,
            msg: '查询数据库失败'
          })
        } else {
          res.send({
            code: 200,
            data: result
          })
        }
      })
    }
  })
})

// 添加职位接口
app.post('/addPost', function(req, res) {
  var userId = req.body.id
  var posname = req.body.posname
  var pospay = req.body.pospay
  var pospay = req.body.pospay
  var posregion = req.body.posregion
  var poseducation = req.body.poseducation
  var posttxt = req.body.posttxt
  var sql = `select id from companylist where user_id='${userId}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      var companyId = result[0].id
      var sql1 = `insert into postlist (posname, pospay, posregion, poseducation, company_id, user_id) values ('${posname}', '${pospay}', '${posregion}', '${poseducation}', '${companyId}', '${userId}')`
      connection.query(sql1, function(err, result) {
        if (err) {
          res.send({
            code: -1002,
            msg: err
          })
        } else {
          var postId = result.insertId
          var sql2 = `insert into postdetail (posttxt, post_id) value ('${posttxt}', '${postId}')`
          connection.query(sql2, function(err, result) {
            if (err) {
              res.send({
                code: -1003,
                msg: err
              })
            } else {
              res.send({
                code: 2,
                msg: '添加成功'
              })
            }
          })
        }
      })
    }
  })
})

// 删除职位接口
app.get('/delPost', function(req, res) {
  var postId = req.query.id
  var sql = `delete from postlist where id='${postId}'; delete from postdetail where post_id='${postId}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 2,
        msg: '删除成功'
      })
    }
  })
})

// 修改职位接口
app.post('/updatePost', function(req, res) {
  var postId = req.body.id
  var posname = req.body.posname
  var pospay = req.body.pospay
  var pospay = req.body.pospay
  var posregion = req.body.posregion
  var poseducation = req.body.poseducation
  var posttxt = req.body.posttxt
  var sql = `update postlist set posname='${posname}', pospay='${pospay}', posregion='${posregion}', poseducation='${poseducation}' where id='${postId}'; update postdetail set posttxt='${posttxt}' where post_id='${postId}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 2,
        msg: '修改成功'
      })
    }
  })
})

// 消息渲染接口
app.get('/message', function(req, res) {
  var userId = req.query.id
  var sql = `select * from message where user_id='${userId}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 200,
        data: result
      })
    }
  })
})

// 删除消息接口
app.get('/delMessage', function(req, res) {
  var id = req.query.id
  var sql = `delete from message where id='${id}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 2,
        msg: '删除成功'
      })
    }
  })
})

// 投递简历接口
app.post('/sendResume', function(req, res) {
  var userId = req.body.userId
  var postId = req.body.postId
  var sql = `select * from resume where user_id='${userId}'; select phone, email from users where id='${userId}'; select user_id from postlist where id='${postId}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      var xm = result[0][0].xingming
      var xl = result[0][0].xueli
      var zw = result[0][0].zhiwei
      var jj = result[0][0].jianjie
      var sj = result[1][0].phone
      var yx = result[1][0].email
      var companyUserId = result[2][0].user_id
      // console.log(result[1][0])

      var sql1 = `insert into message (xm, xl, zw, sj, yx, jj, sender_id, user_id) values ('${xm}', '${xl}', '${zw}', '${sj}', '${yx}', '${jj}', '${userId}', '${companyUserId}')`
      connection.query(sql1, function(err, result) {
        if (err) {
          res.send({
            code: -1001,
            msg: '查询数据库失败'
          })
        } else {
          res.send({
            code: 200,
            msg: '发送成功'
          })
        }
      })
    }
  })
})

// 用户列表渲染接口
app.get('/users', function(req, res) {
  var sql = `select * from users`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 200,
        data: result
      })
    }
  })
})

// 删除用户接口
app.get('/delUsers', function(req, res) {
  var id = req.query.id
  var sql = `delete from users where id='${id}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 2,
        msg: '删除成功'
      })
    }
  })
})

// 文章渲染接口
app.get('/article', function(req, res) {
  var sql = `select * from article`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 200,
        data: result
      })
    }
  })
})

// 文章详情页渲染接口
app.get('/article_detail', function(req, res) {
  var id = req.query.id
  var sql = `
    select * from article where id='${id}'
  `
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1002,
        msg: '查询数据库失败',
        err: err
      })
    } else {
      res.send({
        code: 200,
        data: result
      })
    }
  })
})

// 修改文章接口
app.post('/updateArticle', function(req, res) {
  var id = req.body.id
  var title = req.body.title
  var content = req.body.content
  var sql = `update article set title='${title}', content='${content}' where id='${id}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 2,
        msg: '修改成功'
      })
    }
  })
})

// 删除文章接口
app.get('/delArticle', function(req, res) {
  var id = req.query.id
  var sql = `delete from article where id='${id}'`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 2,
        msg: '删除成功'
      })
    }
  })
})

// 添加文章接口
app.post('/addArticle', function(req, res) {
  var title = req.body.title
  var content = req.body.content
  var sql = `insert into article (title, content) value ('${title}', '${content}')`
  connection.query(sql, function(err, result) {
    if (err) {
      res.send({
        code: -1001,
        msg: '查询数据库失败'
      })
    } else {
      res.send({
        code: 2,
        msg: '添加成功'
      })
    }
  })
})

app.listen(3000, () => {
  console.log('success', function() {
    console.log('服务器启动成功,且地址是', 'http://localhost:3000')
  })
})
