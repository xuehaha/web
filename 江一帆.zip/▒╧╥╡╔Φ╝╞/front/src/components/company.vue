<template>
  <div class="company">
    <Header></Header>
    <div class="company_list w">
      <ul class="clearfix">
        <li v-for="(item, index) in companyList" :key="index" @click="toDetail(item.id)">
          <div class="company_info">
            <img :src="item.comlogo" alt>
            <div class="company_txt">
              <h4>{{item.comname}}</h4>
              <p>{{item.comstatus}} | {{item.comtype}}</p>
            </div>
          </div>
          <div class="about_info">
            <p>{{item.comregion}}</p>
          </div>
        </li>
      </ul>
    </div>
    <Footer></Footer>
  </div>
</template>

<script>
import Header from './header'
import Footer from './footer'
export default {
  data() {
    return {
      companyList: []
    }
  },
  components: {
    Header,
    Footer
  },
  methods: {
    showCompany() {
      this.axios({
        method: 'get',
        url: 'company'
      }).then(res => {
        // console.log(res.data)
        this.companyList = res.data.data
        console.log(this.companyList)
      })
    },
    toDetail(id) {
      this.$router.push({ path: 'company_detail', query: { id: id } })
    }
  },
  created() {
    this.showCompany()
  }
}
</script>

<style lang="less" scoped>
.company {
  .company_list {
    margin-top: 40px;

    ul li {
      width: 248px;
      height: 138px;
      border-left: 2px solid #eee;
      border-bottom: 2px solid #eee;
      background-color: #fff;
      float: left;
      cursor: pointer;

      .company_info {
        width: 206px;
        height: 75px;
        margin: 0 auto;
        padding-top: 20px;
        box-sizing: unset;
        border-bottom: 1px dashed #eee;

        img {
          width: 55px;
          height: 55px;
          float: left;
          border-radius: 10px;
          border: 1px solid #eee;
        }

        .company_txt {
          margin-left: 65px;
          text-align: right;
          overflow: hidden;
          text-overflow: ellipsis;

          h4 {
            font-weight: 500;
            height: 25px;
            line-height: 25px;
            font-size: 16px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin: 0;
          }

          p {
            height: 40px;
            line-height: 41px;
            color: #888;
            font-size: 12px;
            display: inline-block;
            white-space: nowrap;
            margin: 0;
          }
        }
      }

      .about_info {
        height: 42px;
        line-height: 42px;
        font-size: 12px;
        color: #888;

        p {
          text-align: center;
        }
      }
    }
  }
}
</style>
