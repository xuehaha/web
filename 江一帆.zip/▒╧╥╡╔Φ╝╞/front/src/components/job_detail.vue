<template>
  <div class="job_detail">
    <Header></Header>
    <div class="main">
      <div class="job_banner">
        <div class="w">
          <div class="info_primary" v-for="(item, index) in post" :key="index">
            <div class="name">
              <h1>{{item.posname}}</h1>
              <span>{{item.pospay}}</span>
            </div>
            <p>
              {{item.posregion}}
              <em class="dolt"></em>
              {{item.poseducation}}
            </p>
          </div>
          <div class="job_op">
            <button type="text" @click="sendResume">投递简历</button>
          </div>
        </div>
      </div>
      <div class="job_box w">
        <div class="job_detail">
          <div class="detail_top" v-for="(item, index) in detailTop" :key="index">
            <div class="detail_figure">
              <img src="../../static/images/avatar_1.png" alt>
            </div>
            <h2 class="name">{{item.nickname}}</h2>
          </div>
          <div class="detail_content">
            <div class="job_sec">
              <h3>职位描述</h3>
              <div class="text" v-for="(item, index) in detailContent" :key="index">
                <p>{{item.posttxt}}</p>
              </div>
            </div>
          </div>
        </div>
        <div class="job_slide">
          <div class="company" v-for="(item, index) in company" :key="index">
            <p class="title">公司基本信息</p>
            <div class="company_info">
              <a href="javass">
                <img :src="item.comlogo" alt>
              </a>
              <a href="javass">{{item.comname}}</a>
            </div>
            <p>
              <i class="icon_stage"></i>
              {{item.comstatus}}
            </p>
            <p>
              <i class="icon_scale"></i>
              {{item.number}}
            </p>
            <p>
              <i class="icon_industry"></i>
              {{item.comtype}}
            </p>
            <!-- <p class="gray">发布于：2019-03-22 15:11</p> -->
          </div>
        </div>
      </div>
    </div>
    <Footer></Footer>
  </div>
</template>

<script>
import Header from './header'
import Footer from './footer'
export default {
  data() {
    return {
      post: [],
      company: [],
      detailTop: [],
      detailContent: []
    }
  },
  components: {
    Header,
    Footer
  },
  methods: {
    showDetail() {
      var res = location.hash
      var id = res.slice(res.length - 1)
      this.axios({
        method: 'get',
        url: '/job_detail',
        params: {
          id: id
        }
      }).then(res => {
        var result = res.data.data
        this.post = result[0]
        this.company = result[1]
        this.detailTop = result[3]
        this.detailContent = result[2]
        console.log(this.detailTop)
      })
    },
    sendResume() {
      var res2 = location.hash
      var postId = res2.slice(res2.length - 1)

      var res1 = this.$cookies.get('keyname')
      if (!res1) {
        this.$router.push('/login')
      } else {
        var identity = res1.result[0].identity
        var userId = res1.result[0].id
        if (identity === '2') {
          this.$alert('企业用户无法投递简历', '提示', {
            confirmButtonText: '确定'
          })
        } else {
          this.$confirm('确定向该职位投递简历？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消'
          }).then(() => {
            this.axios({
              method: 'get',
              url: 'resume',
              params: {
                id: userId
              }
            }).then(res => {
              var result = res.data.data
              if (result.length === 0) {
                this.$alert('请先填写简历', '提示', {
                  confirmButtonText: '确定'
                })
              } else {
                console.log(userId, postId)
                this.axios({
                  method: 'post',
                  url: 'sendResume',
                  data: {
                    userId: userId,
                    postId: postId
                  }
                }).then(res => {
                  if (res.data.code === 200) {
                    this.$message({
                      type: 'success',
                      message: '投递简历成功!'
                    })
                  }
                })
              }
            })
          })
        }
      }
    }
  },
  created() {
    this.showDetail()
  }
}
</script>

<style lang="less" scoped>
.job_detail {
  .gray {
    color: gray;
  }
  .job_banner {
    padding: 24px 0;
    height: 218px;
    background: url('../../static/images/job_banner.jpg') center no-repeat;
    color: #fff;
    position: relative;

    .info_primary {
      margin-top: 25px;
      float: left;
      color: #4a4160;
      width: 650px;

      .name {
        font-size: 32px;
        line-height: 45px;
        padding: 11px 0 8px;
        color: #fff;

        h1 {
          display: inline-block;
          margin: 0 10px 0 0;
          line-height: 35px;
          overflow: hidden;
          vertical-align: middle;
          font-size: 32px;
          font-weight: 500;
          white-space: nowrap;
          text-overflow: ellipsis;
        }

        span {
          display: inline-block;
          vertical-align: middle;
          color: #fa6a43;
          height: 42px;
          font-size: 30px;
          line-height: 42px;
          font-weight: 600;
        }
      }

      p {
        color: rgba(255, 255, 255, 0.7);

        .dolt {
          display: inline-block;
          vertical-align: middle;
          width: 2px;
          height: 2px;
          margin: 0 10px;
          border-radius: 50%;
          background-color: rgba(255, 255, 255, 0.7);
        }
      }
    }

    .job_op {
      width: 298px;
      float: right;
      button {
        display: inline-block;
        width: 296px;
        height: 45px;
        line-height: 45px;
        box-sizing: border-box;
        border: 1px #26ccfc solid;
        font-size: 16px;
        color: #fff;
        letter-spacing: 1px;
        background-color: #26ccfc;
        text-align: center;
        margin-top: 50px;
        cursor: pointer;
      }
    }
  }

  .job_box {
    margin-top: 20px;
    overflow: hidden;

    .job_slide {
      float: right;
      width: 298px;
      padding-bottom: 40px;

      .company {
        padding-bottom: 10px;
        border-bottom: 1px solid #eee;

        .title {
          font-size: 18px;
          font-weight: 500;
          line-height: 25px;
          margin-bottom: 25px;
        }

        .company_info {
          overflow: hidden;
          line-height: 60px;
          margin-bottom: 27px;

          a {
            color: #414a60;
            text-decoration: none;

            img {
              width: 60px;
              height: 60px;
              float: left;
              margin-right: 18px;
              border-radius: 10px;
            }
          }
        }

        p {
          line-height: 20px;
          margin-bottom: 26px;

          i {
            display: inline-block;
            vertical-align: -4px;
            width: 17px;
            height: 17px;
            margin-right: 25px;
          }

          .icon_stage {
            width: 15px;
            background: url('../../static/images/icon-stage.png') center
              no-repeat;
            background-size: contain;
          }

          .icon_scale {
            background: url('../../static/images/icon-scale.png') center
              no-repeat;
            background-size: contain;
          }

          .icon_industry {
            background: url('../../static/images/icon-industry.png') center
              no-repeat;
            background-size: contain;
          }
        }
      }
    }

    .job_detail {
      position: relative;
      padding-right: 25px;
      border-right: 1px solid #eee;
      margin-right: 322px;
      padding-bottom: 45px;

      .detail_top {
        float: left;
        padding-top: 34px;
        padding-bottom: 0;

        .detail_figure {
          float: left;

          img {
            margin-right: 20px;
            width: 73px;
            height: 73px;
            border-radius: 50%;
          }
        }

        .name {
          float: left;
          margin: 8px 0 0 0;
          font-size: 20px;
          font-weight: 500;
          color: #424a5e;
        }
      }

      .detail_content {
        position: relative;
        float: left;
        margin-left: 30px;

        .job_sec {
          h3 {
            font-weight: 700;
            font-size: 20px;
            color: #424a5e;
            margin-top: 20px;
            margin-bottom: 10px;
          }

          .text {
            color: #61687c;
            line-height: 36px;
          }
        }
      }
    }
  }
}
</style>
