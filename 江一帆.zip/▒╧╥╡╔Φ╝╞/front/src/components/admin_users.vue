<template>
  <div class="admin_users">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item>首页</el-breadcrumb-item>
      <el-breadcrumb-item>用户管理</el-breadcrumb-item>
      <el-breadcrumb-item>用户列表</el-breadcrumb-item>
    </el-breadcrumb>
    <el-table :data="usersList" style="width: 100%">
      <el-table-column prop="username" label="用户名" width="180"></el-table-column>
      <el-table-column prop="identity" label="身份" width="180"></el-table-column>
      <el-table-column prop="phone" label="手机" width="180"></el-table-column>
      <el-table-column prop="email" label="邮箱" width="180"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="danger"
            icon="el-icon-delete"
            plain
            size="small"
            @click="delUsers(scope.row.id)"
          ></el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      usersList: []
    }
  },
  methods: {
    showUsers() {
      this.axios({
        method: 'get',
        url: 'users'
      }).then(res => {
        if (res.data.code === 200) {
          this.usersList = res.data.data
          this.usersList.forEach(item => {
            if (item.identity === '1') {
              item.identity = '用户'
            } else if (item.identity === '2') {
              item.identity = '企业'
            } else {
              item.identity = '管理员'
            }
          })
        }
      })
    },
    delUsers(id) {
      this.$confirm('确定要删除吗？', '提示', {
        type: 'warning'
      }).then(() => {
        this.axios({
          method: 'get',
          url: 'delUsers',
          params: {
            id: id
          }
        }).then(res => {
          console.log(res.data)
          this.showUsers()
        })
      })
    }
  },
  created() {
    this.showUsers()
  }
}
</script>

<style lang="less" scoped>
.el-breadcrumb {
  height: 30px;
  line-height: 30px;
}
</style>
