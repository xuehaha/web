<template>
  <div class="info">
    <Header></Header>
    <div class="main">
      <div class="list_banner">
        <div class="title w">
          <h1>新闻和数据实时跟踪</h1>
        </div>
      </div>
      <div class="list_inner w">
        <div class="list_news">
          <ul>
            <li v-for="item in articleList" :key="item.id" @click="toDetail(item.id)">
              <div class="text">
                <div class="text_title">
                  <p>{{item.title}}</p>
                </div>
                <div class="text_content">
                  <p>{{item.content}}</p>
                </div>
                <div class="text_time">
                  <p>{{item.time}}</p>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <Footer></Footer>
  </div>
</template>

<script>
import Header from './header'
import Footer from './footer'
export default {
  data() {
    return {
      articleList: []
    }
  },
  components: {
    Header,
    Footer
  },
  methods: {
    showArticle() {
      this.axios({
        method: 'get',
        url: 'article'
      }).then(res => {
        if (res.data.code === 200) {
          this.articleList = res.data.data
          this.articleList.forEach(item => {
            item.time = item.time.slice(0, 10)
          })
        }
      })
    },
    toDetail(id) {
      this.$router.push({ path: 'article', query: { id: id } })
    }
  },
  created() {
    this.showArticle()
  }
}
</script>

<style lang="less" scoped>
.info {
  .main {
    position: relative;

    .list_banner {
      height: 398px;
      background: url('../../static/images/info_banner.jpg') center no-repeat;
      background-size: over;

      .title {
        text-align: center;
        color: #fff;
        padding-top: 108px;

        h1 {
          margin: 0;
          font-size: 36px;
          font-weight: 500;
          letter-spacing: 3px;
          line-height: 40px;
        }
      }
    }

    .list_inner {
      margin-top: -150px;
      .list_news {
        background-color: #fff;
        margin-top: 15px;
        padding: 25px 70px;

        ul {
          margin: 0;
        }

        ul li {
          padding: 35px 0;
          border-bottom: 1px solid #eee;
          box-sizing: unset;
          cursor: pointer;

          .text {
            .text_title {
              font-size: 20px;
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
            }

            .text_content {
              height: 75px;
              line-height: 25px;
              color: #666;
              padding: 20px 0 0;
              margin-bottom: 15px;
              overflow: hidden;
            }

            .text_time {
              color: #999;
              line-height: 18px;
              font-size: 14px;
            }
          }
        }
      }
    }
  }
}
</style>
