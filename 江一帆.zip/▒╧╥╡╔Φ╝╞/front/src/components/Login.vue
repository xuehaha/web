<template>
  <div class="login">
    <div class="login_main">
      <div class="login_slide">
        <img src="../../static/images/login_logo.png" alt>
      </div>
      <div class="login_content">
        <h4>用户登录</h4>
        <el-form status-icon ref="form" :rules="rules" :model="form" label-width="80px">
          <el-form-item prop="username">
            <el-input v-model="form.username" placeholder="用户名"></el-input>
          </el-form-item>
          <el-form-item prop="password">
            <el-input type="password" v-model="form.password" placeholder="密码"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="login">登录</el-button>
          </el-form-item>
        </el-form>
        <div class="right_tip">
          <span>没有账号</span>
          <router-link to="/register">立即注册</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      form: {
        username: '',
        password: ''
      },
      rules: {
        username: [
          { required: true, message: '用户名不能为空', trigger: 'blur' },
          {
            min: 3,
            max: 9,
            message: '用户长度在 3 到 9 个字符',
            trigger: 'blur'
          }
        ],
        password: [
          { required: true, message: '密码不能为空', trigger: 'blur' },
          {
            min: 3,
            max: 9,
            message: '密码长度在 6 到 12 个字符',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  methods: {
    login() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.axios({
            method: 'post',
            url: 'login',
            data: this.form
          }).then(res => {
            if (res.data.code === 200) {
              this.$message.success('登录成功')
              this.$cookies.set('keyname', res.data)
              if (res.data.result[0].username === 'admin') {
                this.$router.push('/admin_home')
              } else {
                this.$router.push('/index')
              }
            } else {
              this.$message.error(res.data.msg)
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
  }
}
</script>

<style lang="less">
.login {
  height: 100%;
  background: url('../../static/images/login_bg.jpg') no-repeat;
  background-size: cover;

  .login_main {
    width: 740px;
    height: 514px;
    background-color: #eee;
    border-radius: 20px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);

    .login_slide {
      width: 240px;
      height: 514px;
      border-radius: 20px 0 0 20px;
      background-color: #eee;
      float: left;
    }

    .login_content {
      width: 500px;
      height: 514px;
      margin-left: 240px;
      border-radius: 0 20px 20px 0;
      padding: 68px 65px 50px 65px;
      position: relative;

      h4 {
        font-size: 18px;
        font-weight: 500;
      }

      .el-form {
        margin-top: 35px;

        .el-form-item__content {
          margin-left: 0 !important;
          height: 40px;
        }

        .el-form-item {
          height: 40px;
          margin-bottom: 35px;

          .el-button {
            width: 100%;
            height: 40px;
            background-color: #26ccfc;
            border: none;
            color: #fff;
            font-size: 16px;
          }
        }
      }

      .right_tip {
        float: right;

        span {
          color: #999;
        }

        a {
          color: #26ccfc;
        }
        a:hover {
          text-decoration-line: none;
        }
      }
    }
  }
}
</style>
