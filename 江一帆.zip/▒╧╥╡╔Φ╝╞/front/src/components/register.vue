<template>
  <div class="register">
    <div class="login_main">
      <div class="login_slide">
        <img src="../../static/images/login_logo.png" alt>
      </div>
      <div class="login_content">
        <h4>用户注册</h4>
        <el-form status-icon ref="form" :rules="rules" :model="form" label-width="80px">
          <el-form-item prop="username">
            <el-input v-model="form.username" placeholder="请输入用户名"></el-input>
          </el-form-item>
          <el-form-item prop="password">
            <el-input type="password" v-model="form.password" placeholder="请输入密码"></el-input>
          </el-form-item>
          <el-form-item prop="checkPassword">
            <el-input type="password" v-model="form.checkPassword" placeholder="请确认密码"></el-input>
          </el-form-item>
          <el-form-item prop="identity">
            <el-radio-group v-model="form.identity">
              <el-radio label="1">用户</el-radio>
              <el-radio label="2">企业</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="register">注册</el-button>
          </el-form-item>
        </el-form>
        <div class="right_tip">
          <span>已有账号</span>
          <router-link to="/login">立即登录</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        if (this.form.checkPassword !== '') {
          this.$refs.form.validateField('checkPassword')
        }
        callback()
      }
    }
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.form.password) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      form: {
        username: '',
        password: '',
        checkPassword: '',
        identity: ''
      },
      rules: {
        username: [
          { required: true, message: '用户名不能为空', trigger: 'blur' },
          {
            min: 3,
            max: 9,
            message: '用户长度在 3 到 9 个字符',
            trigger: 'blur'
          }
        ],
        password: [
          { validator: validatePass, trigger: 'blur' },
          {
            min: 3,
            max: 9,
            message: '密码长度在 6 到 12 个字符',
            trigger: 'blur'
          }
        ],
        checkPassword: [{ validator: validatePass2, trigger: 'blur' }],
        identity: [{ required: true, message: '请选择身份', trigger: 'change' }]
      }
    }
  },
  methods: {
    register() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.axios({
            method: 'post',
            url: 'register',
            data: this.form
          }).then(res => {
            if (res.data.code === 2) {
              this.$message.success('注册成功')
              this.$router.push('/login')
            } else {
              this.$message.error(res.data.msg)
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
  }
}
</script>

<style lang="less">
.register {
  height: 100%;
  background: url('../../static/images/login_bg.jpg') no-repeat;
  background-size: cover;

  .login_main {
    width: 740px;
    height: 514px;
    background-color: #eee;
    border-radius: 20px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);

    .login_slide {
      width: 240px;
      height: 514px;
      border-radius: 20px 0 0 20px;
      background-color: #eee;
      float: left;
    }

    .login_content {
      width: 500px;
      height: 514px;
      margin-left: 240px;
      border-radius: 0 20px 20px 0;
      padding: 68px 65px 50px 65px;
      position: relative;

      h4 {
        font-size: 18px;
        font-weight: 500;
      }

      .el-form {
        margin-top: 35px;

        .el-form-item__content {
          margin-left: 0 !important;
          height: 40px;
        }

        .el-form-item {
          height: 40px;
          margin-bottom: 25px;

          .el-button {
            width: 100%;
            height: 40px;
            background-color: #26ccfc;
            border: none;
            color: #fff;
            font-size: 16px;
          }
        }
      }

      .right_tip {
        float: right;

        span {
          color: #999;
        }

        a {
          color: #26ccfc;
        }
        a:hover {
          text-decoration-line: none;
        }
      }
    }
  }
}
</style>
