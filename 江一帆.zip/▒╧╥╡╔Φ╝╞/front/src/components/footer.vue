<template>
  <div class="footer">
    <p>
      Copyright @ 2018-2019 大学生求职招聘网 All Rights Reserved
      豫ICP备123456789号 联系我们：714347650@qq.com
    </p>
  </div>
</template>

<script>
export default {}
</script>

<style lang="less">
.footer {
  margin-top: 50px;

  p {
    // font-size: 16px;
    text-align: center;
  }
}
</style>
