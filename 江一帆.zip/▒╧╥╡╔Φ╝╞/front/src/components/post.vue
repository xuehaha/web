<template>
  <div class="post">
    <Header></Header>
    <div class="search w">
      <input type="text" v-model="input" placeholder="请输入关键字">
      <a href @click.prevent="search">
        <span class="el-icon-search"></span>
      </a>
    </div>
    <div class="job_list w">
      <ul v-if="isCount">
        <li v-for="(item, index) in postList" :key="index" @click="toDetail(item.id)">
          <div class="job_primary">
            <div class="info_primary">
              <h3>
                {{item.posname}}
                <span>{{item.pospay}}</span>
              </h3>
              <p>{{item.posregion}} | {{item.poseducation}}</p>
            </div>
            <div class="info_company">
              <h3>{{item.comname}}</h3>
              <p>{{item.comtype}}</p>
            </div>
            <div class="info_publis">
              <h3>
                <img src="../../static/images/avatar_1.png" alt>
                {{item.nickname}}
              </h3>
              <!-- <p>发布于03月19号</p> -->
            </div>
          </div>
        </li>
      </ul>
      <div class="null" v-else>暂无更多数据</div>
    </div>
    <Footer></Footer>
  </div>
</template>

<script>
import Header from './header'
import Footer from './footer'
export default {
  data() {
    return {
      input: '',
      postList: [],
      isCount: true
    }
  },
  components: {
    Header,
    Footer
  },
  methods: {
    showPost() {
      this.axios({
        method: 'get',
        url: 'post'
      }).then(res => {
        this.postList = res.data.data
        console.log(this.postList)
      })
    },
    toDetail(id) {
      this.$router.push({ path: 'job_detail', query: { id: id } })
    },
    search() {
      var value = this.input.trim()
      this.axios({
        method: 'get',
        url: 'search',
        params: {
          value: value
        }
      }).then(res => {
        var result = res.data.data
        this.postList = result
        if (this.postList.length === 0) {
          this.isCount = false
        }
      })
    },
    showSearch() {
      var res = location.hash
      res = decodeURI(res)
      var value = res.slice(13)
      this.input = value
      this.axios({
        method: 'get',
        url: 'search',
        params: {
          value: value
        }
      }).then(res => {
        var result = res.data.data
        this.postList = result
        if (this.postList.length === 0) {
          this.isCount = false
        }
      })
    }
  },
  created() {
    this.showPost()
    this.showSearch()
  }
}
</script>

<style lang="less" scoped>
.post {
  .search {
    margin-top: 30px;
    height: 42px;
    position: relative;

    input {
      position: absolute;
      top: 0;
      left: 0;
      width: 650px;
      height: 42px;
      border: 1px solid #26ccfc;
      padding: 10px 20px;
      font-size: 16px;
    }

    a {
      width: 100px;
      height: 42px;
      position: absolute;
      top: 0;
      left: 650px;
      background-color: #26ccfc;
      color: #fff;
      text-align: center;
      line-height: 42px;
      font-size: 20px;
    }
  }

  .job_list {
    margin-top: 50px;

    ul {
      width: 726px;
      margin: 0;
      background-color: #fff;
    }

    ul li {
      height: 95px;
      cursor: pointer;

      .job_primary {
        margin: 0 30px;
        padding: 22px 0;
        border-bottom: 1px solid #ddd;
        box-sizing: border-box;
        height: 95px;

        .info_primary {
          // height: 54px;
          width: 270px;
          margin-right: 15px;
          float: left;

          h3 {
            font-weight: 500;
            font-size: 16px;
            color: #26ccfc;
            height: 26px;
            line-height: 26px;
            margin: 0;

            span {
              margin-left: 10px;
              color: red;
            }
          }

          p {
            margin-top: 2px;
            margin-bottom: 0;
            font-size: 12px;
            color: #999;
          }
        }

        .info_company {
          width: 210px;
          margin-right: 15px;
          float: left;

          h3 {
            font-weight: 500;
            font-size: 16px;
            height: 26px;
            line-height: 26px;
            margin: 0;
          }

          p {
            margin-top: 2px;
            margin-bottom: 0;
            font-size: 12px;
            color: #999;
          }
        }

        .info_publis {
          width: 155px;
          float: left;

          h3 {
            font-weight: 500;
            font-size: 13px;
            height: 26px;
            line-height: 26px;
            margin: 0;

            img {
              width: 20px;
              height: 20px;
              border-radius: 40px;
              vertical-align: middle;
              margin: -3px 10px 0 0;
              display: inline-block;
            }
          }

          p {
            margin-top: 2px;
            margin-bottom: 0;
            font-size: 12px;
            color: #999;
          }
        }
      }
    }

    .null {
      margin-left: 300px;
    }
  }
}
</style>
