<template>
  <div class="personal">
    <Header></Header>
    <div class="person_main">
      <div class="account w">
        <h3 class="title">个人中心</h3>
        <el-tabs :tab-position="tabPosition">
          <el-tab-pane label="个人资料">
            <div class="personal_data" v-for="(item, index) in PersonDetail" :key="index">
              <div class="headphoto">
                <img src="../../static/images/avatar_1.png" alt>
              </div>
              <div class="detail">
                <ul>
                  <li>
                    用户名:
                    <span>{{item.username}}</span>
                  </li>
                  <li>
                    昵称:
                    <span>{{item.nickname}}</span>
                  </li>
                  <li>
                    手机:
                    <span>{{item.phone}}</span>
                  </li>
                  <li>
                    邮箱:
                    <span>{{item.email}}</span>
                  </li>
                </ul>
              </div>
            </div>
            <el-button class="update" type="primary" @click="showInfo">修改资料</el-button>

            <el-dialog title="修改资料" :visible.sync="editInfoDialogFormVisible">
              <el-form :model="form1" :rules="rules1" ref="form1">
                <el-form-item label="昵称" :label-width="formLabelWidth" prop="nickname">
                  <el-input v-model="form1.nickname" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="手机" :label-width="formLabelWidth" prop="phone">
                  <el-input v-model="form1.phone" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="邮箱" :label-width="formLabelWidth" prop="email">
                  <el-input v-model="form1.email" autocomplete="off"></el-input>
                </el-form-item>
              </el-form>
              <div slot="footer" class="dialog-footer">
                <el-button @click="editInfoDialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="updateInfo">确 定</el-button>
              </div>
            </el-dialog>
          </el-tab-pane>
          <el-tab-pane label="我的消息" v-if="isCompay">
            <div class="message">
              <el-table :data="messageList" style="width: 100%">
                <el-table-column prop="zw" label="消息" width="400"></el-table-column>
                <el-table-column prop="xm" label="发送人" width="150"></el-table-column>
                <el-table-column label="操作">
                  <template slot-scope="scope">
                    <el-button
                      type="primary"
                      icon="el-icon-edit"
                      size="small"
                      @click="messageDialog(scope.row)"
                    ></el-button>
                    <el-button
                      type="danger"
                      icon="el-icon-delete"
                      size="small"
                      @click="delMessage(scope.row.id)"
                    ></el-button>
                  </template>
                </el-table-column>
              </el-table>

              <!-- 查看消息对话框 -->
              <el-dialog title="个人简历" :visible.sync="showMessageDialog">
                <el-form
                  :model="messageForm"
                  ref="messageForm"
                  :rules="postRules"
                  class="show_message"
                >
                  <el-form-item label="姓名" :label-width="formLabelWidth">{{messageForm.xm}}</el-form-item>
                  <el-form-item label="学历" :label-width="formLabelWidth">{{messageForm.xl}}</el-form-item>
                  <el-form-item label="职位" :label-width="formLabelWidth">{{messageForm.zw}}</el-form-item>
                  <el-form-item label="手机" :label-width="formLabelWidth">{{messageForm.sj}}</el-form-item>
                  <el-form-item label="邮箱" :label-width="formLabelWidth">{{messageForm.yx}}</el-form-item>
                  <el-form-item label="简介" :label-width="formLabelWidth">{{messageForm.jj}}</el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                  <el-button type="primary" @click="showMessageDialog = false">确 定</el-button>
                </div>
              </el-dialog>
            </div>
          </el-tab-pane>
          <el-tab-pane label="个人简历" v-if="isUser">
            <div class="resume">
              <ul v-for="(item, index) in resumeList" :key="index">
                <li>
                  姓名：
                  <span>{{item.xingming}}</span>
                </li>
                <li>
                  学历：
                  <span>{{item.xueli}}</span>
                </li>
                <li>
                  应聘职位：
                  <span>{{item.zhiwei}}</span>
                </li>
                <li>
                  个人简介：
                  <span>{{item.jianjie}}</span>
                </li>
              </ul>
            </div>
            <el-button class="resume_edit" type="primary" @click="editResume">编辑简历</el-button>

            <el-dialog title="编辑简历" :visible.sync="editResumeDialogFormVisible">
              <el-form :model="form2" :rules="rules2" ref="form2">
                <el-form-item label="姓名" :label-width="formLabelWidth" prop="xingming">
                  <el-input v-model="form2.xingming" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="学历" :label-width="formLabelWidth" prop="xueli">
                  <el-input v-model="form2.xueli" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="应聘职位" :label-width="formLabelWidth" prop="zhiwei">
                  <el-input v-model="form2.zhiwei" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="个人简介" :label-width="formLabelWidth" prop="jianjie">
                  <el-input type="textarea" v-model="form2.jianjie"></el-input>
                </el-form-item>
              </el-form>
              <div slot="footer" class="dialog-footer">
                <el-button @click="editResumeDialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="updateResume">确 定</el-button>
              </div>
            </el-dialog>
          </el-tab-pane>
          <el-tab-pane label="发布求职" v-else>
            <div class="publish">
              <el-button
                plain
                class="add"
                size="small"
                @click="addPostDialogFormVisible = true"
              >添加职位</el-button>
              <el-table :data="postList" style="width: 100%">
                <el-table-column prop="posname" label="名称"></el-table-column>
                <el-table-column prop="pospay" label="薪资"></el-table-column>
                <el-table-column prop="posregion" label="地区"></el-table-column>
                <el-table-column prop="poseducation" label="学历"></el-table-column>
                <el-table-column prop="posttxt" label="要求"></el-table-column>
                <el-table-column label="操作">
                  <template slot-scope="scope">
                    <el-button
                      type="primary"
                      icon="el-icon-edit"
                      plain
                      size="small"
                      @click="showEditPost(scope.row)"
                    ></el-button>
                    <el-button
                      type="danger"
                      icon="el-icon-delete"
                      plain
                      size="small"
                      @click="delPost(scope.row.id)"
                    ></el-button>
                  </template>
                </el-table-column>
              </el-table>

              <!-- 添加职位对话框 -->
              <el-dialog title="添加职位" :visible.sync="addPostDialogFormVisible">
                <el-form :model="addPostForm" ref="addPostForm" :rules="postRules">
                  <el-form-item label="名称" :label-width="formLabelWidth" prop="posname">
                    <el-input v-model="addPostForm.posname" autocomplete="off"></el-input>
                  </el-form-item>
                  <el-form-item label="薪资" :label-width="formLabelWidth" prop="pospay">
                    <el-input v-model="addPostForm.pospay" autocomplete="off"></el-input>
                  </el-form-item>
                  <el-form-item label="地区" :label-width="formLabelWidth" prop="posregion">
                    <el-input v-model="addPostForm.posregion" autocomplete="off"></el-input>
                  </el-form-item>
                  <el-form-item label="学历" :label-width="formLabelWidth" prop="poseducation">
                    <el-input v-model="addPostForm.poseducation" autocomplete="off"></el-input>
                  </el-form-item>
                  <el-form-item label="要求" :label-width="formLabelWidth" prop="posttxt">
                    <el-input type="textarea" v-model="addPostForm.posttxt" autocomplete="off"></el-input>
                  </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                  <el-button @click="addPostDialogFormVisible = false">取 消</el-button>
                  <el-button type="primary" @click="addPost">确 定</el-button>
                </div>
              </el-dialog>

              <!-- 修改职位对话框 -->
              <el-dialog title="编辑职位" :visible.sync="updatePostDialog">
                <el-form :model="updatePostForm" ref="updatePostForm" :rules="postRules">
                  <el-form-item label="名称" :label-width="formLabelWidth" prop="posname">
                    <el-input v-model="updatePostForm.posname" autocomplete="off"></el-input>
                  </el-form-item>
                  <el-form-item label="薪资" :label-width="formLabelWidth" prop="pospay">
                    <el-input v-model="updatePostForm.pospay" autocomplete="off"></el-input>
                  </el-form-item>
                  <el-form-item label="地区" :label-width="formLabelWidth" prop="posregion">
                    <el-input v-model="updatePostForm.posregion" autocomplete="off"></el-input>
                  </el-form-item>
                  <el-form-item label="学历" :label-width="formLabelWidth" prop="poseducation">
                    <el-input v-model="updatePostForm.poseducation" autocomplete="off"></el-input>
                  </el-form-item>
                  <el-form-item label="要求" :label-width="formLabelWidth" prop="posttxt">
                    <el-input type="textarea" v-model="updatePostForm.posttxt" autocomplete="off"></el-input>
                  </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                  <el-button @click="updatePostDialog = false">取 消</el-button>
                  <el-button type="primary" @click="updatePost">确 定</el-button>
                </div>
              </el-dialog>
            </div>
          </el-tab-pane>
          <el-tab-pane label="修改密码">
            <div class="editPassword">
              <el-form status-icon ref="form" :rules="rules" :model="form" label-width="80px">
                <el-form-item prop="password" label="设置密码">
                  <el-input type="password" v-model="form.password" placeholder="请输入密码"></el-input>
                </el-form-item>
                <el-form-item prop="checkPassword">
                  <el-input type="password" v-model="form.checkPassword" placeholder="请确认密码"></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="updatePass">设置密码</el-button>
                </el-form-item>
              </el-form>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
    <Footer></Footer>
  </div>
</template>

<script>
import Header from './header'
import Footer from './footer'
export default {
  data() {
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        if (this.form.checkPassword !== '') {
          this.$refs.form.validateField('checkPassword')
        }
        callback()
      }
    }
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.form.password) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    var checkPhone = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('手机号不能为空'))
      } else {
        const reg = /^1[3|4|5|7|8][0-9]\d{8}$/
        if (reg.test(value)) {
          callback()
        } else {
          return callback(new Error('请输入正确的手机号'))
        }
      }
    }
    return {
      tabPosition: 'left',
      isUser: false,
      isCompay: true,
      PersonDetail: [],
      resumeList: [],

      messageList: [],
      postList: [],

      form: {
        password: '',
        checkPassword: ''
      },
      rules: {
        password: [
          { validator: validatePass, trigger: 'blur' },
          {
            min: 3,
            max: 9,
            message: '密码长度在 6 到 12 个字符',
            trigger: 'blur'
          }
        ],
        checkPassword: [{ validator: validatePass2, trigger: 'blur' }]
      },

      editInfoDialogFormVisible: false,
      editResumeDialogFormVisible: false,
      addPostDialogFormVisible: false,
      updatePostDialog: false,
      showMessageDialog: false,

      form1: {
        nickname: '',
        phone: '',
        email: ''
      },
      rules1: {
        nickname: [
          { required: true, message: '请输入昵称', trigger: 'blur' },
          { min: 2, max: 5, message: '长度在 2 到 5 个字符', trigger: 'blur' }
        ],
        phone: [{ validator: checkPhone, trigger: 'blur' }],
        email: [
          { required: true, message: '请输入邮箱地址', trigger: 'blur' },
          {
            type: 'email',
            message: '请输入正确的邮箱地址',
            trigger: 'blur'
          }
        ]
      },
      formLabelWidth: '120px',

      form2: {
        xingming: '',
        xueli: '',
        zhiwei: '',
        jianjie: ''
      },
      rules2: {
        xingming: [{ required: true, message: '请填写姓名', trigger: 'blur' }],
        xueli: [{ required: true, message: '请填写学历', trigger: 'blur' }],
        zhiwei: [{ required: true, message: '请填写职位', trigger: 'blur' }],
        jianjie: [
          { required: true, message: '请填写个人简介', trigger: 'blur' }
        ]
      },

      addPostForm: {
        posname: '',
        pospay: '',
        posregion: '',
        poseducation: '',
        posttxt: ''
      },
      postRules: {
        posname: [{ required: true, message: '请填写名称', trigger: 'blur' }],
        pospay: [{ required: true, message: '请填写薪资', trigger: 'blur' }],
        posregion: [{ required: true, message: '请填写地区', trigger: 'blur' }],
        poseducation: [
          { required: true, message: '请填写学历', trigger: 'blur' }
        ],
        posttxt: [{ required: true, message: '请填写要求', trigger: 'blur' }]
      },
      updatePostForm: {
        id: '',
        posname: '',
        pospay: '',
        posregion: '',
        poseducation: '',
        posttxt: ''
      },
      messageForm: {
        xm: '',
        xl: '',
        zw: '',
        sj: '',
        yx: '',
        jj: ''
      }
    }
  },
  components: {
    Header,
    Footer
  },
  methods: {
    showPerson() {
      var res = this.$cookies.get('keyname')
      var id = res.result[0].id
      this.axios({
        method: 'get',
        url: 'personal',
        params: {
          id: id
        }
      }).then(res => {
        this.PersonDetail = res.data.data
      })
    },
    showResume() {
      var res = this.$cookies.get('keyname')
      var identity = parseInt(res.result[0].identity)
      console.log(identity)

      if (identity === 1) {
        this.isUser = true
        this.isCompay = false
      }
    },
    updatePass() {
      var res = this.$cookies.get('keyname')
      var username = res.result[0].username
      this.$refs.form.validate(valid => {
        if (valid) {
          this.axios({
            method: 'post',
            url: 'updatePass',
            data: {
              username: username,
              password: this.form.password
            }
          }).then(res => {
            if (res.data.code === 2) {
              this.$message.success(res.data.msg)
              this.$router.push('/login')
            } else {
              this.$message.error(res.data.msg)
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    showInfo() {
      this.editInfoDialogFormVisible = true
      this.form1.nickname = this.PersonDetail[0].nickname
      this.form1.phone = this.PersonDetail[0].phone
      this.form1.email = this.PersonDetail[0].email
    },
    updateInfo() {
      var res = this.$cookies.get('keyname')
      var id = res.result[0].id
      // this.dialogFormVisible = false
      this.$refs.form1.validate(valid => {
        this.axios({
          method: 'post',
          url: 'updateInfo',
          data: {
            id: id,
            nickname: this.form1.nickname,
            phone: this.form1.phone,
            email: this.form1.email
          }
        }).then(res => {
          this.editInfoDialogFormVisible = false
          this.showPerson()
        })
      })
    },
    resume() {
      var res = this.$cookies.get('keyname')
      var id = res.result[0].id
      this.axios({
        method: 'get',
        url: 'resume',
        params: {
          id: id
        }
      }).then(res => {
        this.resumeList = res.data.data
        console.log(this.resumeList)
      })
    },
    editResume() {
      this.editResumeDialogFormVisible = true
      this.form2.xingming = this.resumeList[0].xingming
      this.form2.xueli = this.resumeList[0].xueli
      this.form2.zhiwei = this.resumeList[0].zhiwei
      this.form2.jianjie = this.resumeList[0].jianjie
    },
    updateResume() {
      // this.dialogFormVisible = false
      var res = this.$cookies.get('keyname')
      var id = res.result[0].id
      this.$refs.form2.validate(valid => {
        this.axios({
          method: 'post',
          url: 'updateResume',
          data: {
            id: id,
            user_id: this.resumeList.user_id,
            xingming: this.form2.xingming,
            xueli: this.form2.xueli,
            zhiwei: this.form2.zhiwei,
            jianjie: this.form2.jianjie
          }
        }).then(res => {
          this.resume()
          this.editResumeDialogFormVisible = false
        })
      })
    },
    publish() {
      if (this.isUser === false) {
        var res = this.$cookies.get('keyname')
        var id = res.result[0].id
        this.axios({
          method: 'get',
          url: 'publish',
          params: {
            id: id
          }
        }).then(res => {
          this.postList = res.data.data
          console.log(this.postList)
        })
      }
    },
    delPost(id) {
      this.$confirm('确定要删除吗？', '提示', {
        type: 'warning'
      }).then(() => {
        this.axios({
          method: 'get',
          url: 'delPost',
          params: {
            id: id
          }
        }).then(res => {
          console.log(res.data)
          this.publish()
        })
      })
    },
    addPost() {
      var res = this.$cookies.get('keyname')
      var id = res.result[0].id
      this.$refs.addPostForm.validate(valid => {
        if (!valid) return false
        this.axios({
          method: 'post',
          url: 'addPost',
          data: {
            id: id,
            posname: this.addPostForm.posname,
            pospay: this.addPostForm.pospay,
            posregion: this.addPostForm.posregion,
            poseducation: this.addPostForm.poseducation,
            posttxt: this.addPostForm.posttxt
          }
        }).then(res => {
          if (res.data.code === 2) {
            this.publish()
            this.$refs.addPostForm.resetFields()
            this.addPostDialogFormVisible = false
          }
        })
      })
    },
    showEditPost(row) {
      this.updatePostDialog = true
      this.updatePostForm.id = row.id
      this.updatePostForm.posname = row.posname
      this.updatePostForm.pospay = row.pospay
      this.updatePostForm.posregion = row.posregion
      this.updatePostForm.poseducation = row.poseducation
      this.updatePostForm.posttxt = row.posttxt
    },
    updatePost() {
      this.$refs.updatePostForm.validate(valid => {
        if (!valid) return false
        this.axios({
          method: 'post',
          url: 'updatePost',
          data: this.updatePostForm
        }).then(res => {
          if (res.data.code === 2) {
            this.updatePostDialog = false
            this.$refs.updatePostForm.resetFields()
            this.publish()
          }
        })
      })
    },
    showMessage() {
      if (this.isCompay === true) {
        var res = this.$cookies.get('keyname')
        var id = res.result[0].id
        this.axios({
          method: 'get',
          url: 'message',
          params: {
            id: id
          }
        }).then(res => {
          this.messageList = res.data.data
          console.log(this.messageList)
        })
      }
    },
    messageDialog(row) {
      this.showMessageDialog = true
      this.messageForm.xm = row.xm
      this.messageForm.xl = row.xl
      this.messageForm.zw = row.zw
      this.messageForm.sj = row.sj
      this.messageForm.yx = row.yx
      this.messageForm.jj = row.jj
    },
    delMessage(id) {
      this.$confirm('确定要删除吗？', '提示', {
        type: 'warning'
      }).then(() => {
        this.axios({
          method: 'get',
          url: 'delMessage',
          params: {
            id: id
          }
        }).then(res => {
          console.log(res.data)
          this.showMessage()
        })
      })
    }
  },
  created() {
    this.showPerson()
    this.showResume()
    this.resume()
    this.publish()
    this.showMessage()
  }
}
</script>

<style lang="less" scoped>
.personal {
  /deep/.el-table .cell {
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .person_main {
    margin-top: 20px;

    .account {
      .title {
        font-size: 20px;
        font-weight: 500;
        padding: 30px 0;
        margin: 0;
      }

      /deep/.el-tabs--left .el-tabs__header.is-left {
        margin-right: 20px;

        /deep/.el-tabs__item {
          padding: 0 50px;
          height: 60px;
          line-height: 60px;
          font-size: 16px;
        }
      }

      .personal_data {
        padding: 20px 0;
        overflow: hidden;

        .headphoto {
          margin-left: 30px;
          float: left;

          img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
          }
        }

        .detail {
          float: left;
          margin-left: 30px;

          li {
            height: 40px;
            line-height: 40px;

            span {
              margin-left: 10px;
            }
          }
        }
      }

      .update {
        margin-left: 160px;
      }

      /deep/input[type='text'] {
        border: 1px solid #dcdfe6;
      }

      .message {
        // padding: 20px 0;

        .message_title {
          border: 1px solid #ccc;
          height: 30px;
          background-color: #eee;

          li {
            float: left;
            line-height: 30px;
            text-align: center;
          }

          li:nth-child(1) {
            width: 50%;
            border-right: 1px solid #ccc;
          }
          li:nth-child(2) {
            width: 25%;
            border-right: 1px solid #ccc;
          }
          li:nth-child(3) {
            width: 25%;
          }
        }
        .message_txt {
          border: 1px solid #ccc;
          border-top: none;
          height: 50px;
          // background-color: #eee;

          li {
            float: left;
            line-height: 50px;
            text-align: center;
          }

          li:nth-child(1) {
            width: 50%;
            border-right: 1px solid #ccc;
          }
          li:nth-child(2) {
            width: 25%;
            border-right: 1px solid #ccc;
          }
          li:nth-child(3) {
            width: 25%;
          }
        }
        .show_message .el-form-item {
          margin-bottom: 0;
        }
      }

      .resume {
        // padding: 20px;
        // font-size: 16px;

        li {
          // height: 30px;
          // line-height: 30px;
          margin-bottom: 10px;

          span {
            margin-left: 10px;
          }
        }
      }
      .resume_edit {
        margin-top: 20px;
      }

      .publish {
        .add {
          margin-bottom: 10px;
        }
      }

      .editPassword {
        padding: 10px 0;

        .el-form {
          width: 400px;
        }
      }
    }
  }
}
</style>
