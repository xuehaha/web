<template>
  <div class="company_detail">
    <Header></Header>
    <div class="main">
      <div class="company_banner">
        <div class="w">
          <div class="info_primary" v-for="(item, index) in company" :key="index">
            <img :src="item.comlogo" alt>
            <div class="info">
              <h1 class="name">{{item.comname}}</h1>
              <p>
                {{item.comstatus}}
                <em class="dolt"></em>
                {{item.number}}
                <em class="dolt"></em>
                {{item.comtype}}
              </p>
            </div>
          </div>
        </div>
      </div>
      <div class="company_job">
        <div class="w">
          <h3>在招职位</h3>
          <ul>
            <li v-for="(item, index) in post" :key="index">
              <a href @click.prevent="toDetail(item.id)">
                <div class="info_primary">
                  <div class="name">
                    <span>{{item.pospay}}</span>
                    <b>{{item.posname}}</b>
                  </div>
                  <p>{{item.poseducation}}·{{item.posregion}}</p>
                </div>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div class="job_box">
        <div class="w">
          <div class="job_detail">
            <div class="job_sec">
              <h3>公司简介</h3>
              <div class="text" v-for="(item, index) in detail" :key="index">{{item.companytxt}}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <Footer></Footer>
  </div>
</template>

<script>
import Header from './header'
import Footer from './footer'
export default {
  data() {
    return {
      company: [],
      post: [],
      detail: []
    }
  },
  components: {
    Header,
    Footer
  },
  methods: {
    showDetail() {
      var res = location.hash
      var id = res.slice(res.length - 1)
      this.axios({
        method: 'get',
        url: '/company_detail',
        params: {
          id: id
        }
      }).then(res => {
        var result = res.data.data
        this.company = result[0]
        this.post = result[1]
        this.detail = result[2]
      })
    },
    toDetail(id) {
      this.$router.push({ path: 'job_detail', query: { id: id } })
    }
  },
  created() {
    this.showDetail()
  }
}
</script>

<style lang="less" scoped>
.company_detail {
  .dolt {
    display: inline-block;
    vertical-align: middle;
    width: 2px;
    height: 2px;
    margin: 0 10px;
    border-radius: 50%;
    background-color: rgba(255, 255, 255, 0.7);
    font-style: normal;
  }

  .gray {
    color: gray;
  }
  .main {
    position: relative;

    .company_banner {
      padding-top: 28px;
      background-color: #444c5f;
      background-position: center 0;
      background-repeat: no-repeat;
      background-size: auto 100%;
      color: #fff;
      padding: 29px 0;

      .info_primary {
        position: relative;
        color: #fff;

        img {
          width: 103px;
          height: 103px;
          border-radius: 13px;
          display: inline-block;
          vertical-align: middle;
        }

        .info {
          margin-left: 25px;
          display: inline-block;
          vertical-align: middle;

          .name {
            margin: 0;
            font-size: 32px;
            font-weight: 500;
            line-height: 45px;
            padding: 0 0 5px 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            color: #fff;
          }

          p {
            margin-top: 30px;
            line-height: 20px;
            padding: 0;
            color: rgba(255, 255, 255, 0.7);
            margin-bottom: 15px;
          }
        }
      }
    }

    .company_job {
      background: #f2f2f5;
      padding: 25px 0 18px;
      overflow: hidden;

      h3 {
        margin: 0;
        font-size: 16px;
        font-weight: 500;
        padding-bottom: 20px;
      }

      ul li {
        display: inline-block;
        font-size: 14px;
        margin-right: 15px;

        a {
          display: block;
          width: 283px;
          padding: 19px 20px 17px;
          border: 1px #fff solid;
          background: #fff;
          text-decoration: none;
          color: #414a60;

          .name {
            padding-bottom: 10px;

            span {
              color: #fc703e;
              float: right;
              font-size: 16px;
            }

            b {
              font-weight: 400;
              font-size: 16px;
              display: block;
              max-width: 152px;
              overflow: hidden;
              white-space: nowrap;
              text-overflow: ellipsis;
            }
          }

          p {
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
        }
      }
    }

    .job_box {
      margin-top: 20px;

      .job_detail {
        position: relative;
        padding-right: 25px;
        border-right: 1px #f5f7f9 solid;
        margin-right: 322px;
        padding-bottom: 45px;

        .job_sec {
          position: relative;

          h3 {
            font-weight: 700;
            font-size: 15px;
            color: #424a5e;
            margin: 0;
            line-height: 50px;
            padding: 0 0 10px 0;
            margin-top: 5px;
            margin-bottom: 0;
          }

          .text {
            overflow: hidden;
            position: relative;
            color: #61687c;
            line-height: 36px;
          }
        }
      }
    }
  }
}
</style>
