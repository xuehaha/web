<template>
  <div class="article">
    <Header></Header>
    <div class="main w">
      <div class="detail" v-for="item in articleList" :key="item.id">
        <h1 class="title">{{item.title}}</h1>
        <div class="info">
          <div class="time">
            <span>{{item.time}}</span>
          </div>
        </div>
        <div class="content">
          <p>{{item.content}}</p>
        </div>
      </div>
    </div>
    <Footer></Footer>
  </div>
</template>

<script>
import Header from './header'
import Footer from './footer'
export default {
  data() {
    return {
      articleList: []
    }
  },
  components: {
    Header,
    Footer
  },
  methods: {
    showArticle() {
      var res = location.hash
      var id = res.slice(res.length - 1)
      this.axios({
        method: 'get',
        url: 'article_detail',
        params: {
          id: id
        }
      }).then(res => {
        if (res.data.code === 200) {
          this.articleList = res.data.data
          this.articleList.forEach(item => {
            item.time = item.time.slice(0, 10)
          })
        }
      })
    }
  },
  created() {
    this.showArticle()
  }
}
</script>

<style lang="less" scoped>
.article {
  .main {
    margin-top: 20px;
    width: 796px;

    .detail {
      padding: 35px 45px 45px;
      background-color: #fff;
      font-size: 16px;
      letter-spacing: 0.5px;
      line-height: 30px;

      .title {
        font-size: 30px;
        font-weight: 500;
        line-height: 50px;
        margin: 0;
      }

      .info {
        color: #999;
        line-height: 18px;
        font-size: 14px;
        height: 83px;

        .time {
          float: right;
          margin-top: 30px;
        }
      }

      .content {
        p {
          padding: 15px 0;
        }
      }
    }
  }
}
</style>
