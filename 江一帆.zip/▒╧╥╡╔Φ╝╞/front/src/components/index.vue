<template>
  <div class="index">
    <Header></Header>
    <div class="banner"></div>
    <div class="search w">
      <input type="text" v-model="input" placeholder="请输入关键字">
      <a href="#" @click.prevent="search">搜索</a>
    </div>
    <div class="main w">
      <div class="position">
        <ul>
          <li v-for="item in jobClass" :key="item.id">
            <b>{{item.category}}</b>
            <a href @click.prevent="toPost">{{item.sort_1}}</a>
            <a href @click.prevent="toPost">{{item.sort_2}}</a>
            <a href @click.prevent="toPost">{{item.sort_3}}</a>
          </li>
        </ul>
      </div>
      <div class="advert">
        <div class="block">
          <el-carousel height="315px">
            <el-carousel-item>
              <img src="../../static/images/adv1.jpg" alt>
            </el-carousel-item>
            <el-carousel-item>
              <img src="../../static/images/adv2.jpg" alt>
            </el-carousel-item>
            <el-carousel-item>
              <img src="../../static/images/adv3.jpg" alt>
            </el-carousel-item>
          </el-carousel>
        </div>
      </div>
    </div>
    <Footer></Footer>
  </div>
</template>

<script>
import Header from './header'
import Footer from './footer'
export default {
  data() {
    return {
      input: '',
      jobClass: []
    }
  },
  components: {
    Header,
    Footer
  },
  methods: {
    showJob() {
      this.axios({
        method: 'get',
        url: 'index'
      }).then(res => {
        this.jobClass = res.data.data
        console.log(this.jobClass)
      })
    },
    search() {
      var value = this.input.trim()
      this.$router.push({ path: 'post', query: { value: value } })
    },
    toPost() {
      console.log(111)
    }
  },
  created() {
    this.showJob()
  }
}
</script>

<style lang="less" scoped>
.el-carousel__item h3 {
  color: #475669;
  font-size: 14px;
  opacity: 0.75;
  line-height: 150px;
  margin: 0;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n + 1) {
  background-color: #d3dce6;
}

.w {
  width: 1000px;
  margin: 0 auto;
}

.banner {
  height: 150px;
  position: relative;
  background: url('../../static/images/banner.jpg');
  background-size: cover;
}

.search {
  width: 935px;
  height: 50px;
  margin-top: 20px;
  background-color: pink;
  position: relative;

  input {
    width: 795px;
    height: 50px;
    padding: 10px 20px;
    font-size: 16px;
    box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.13);
  }

  a {
    display: block;
    width: 140px;
    height: 50px;
    background-color: #26ccfc;
    color: #fff;
    line-height: 50px;
    font-size: 16px;
    text-align: center;
    position: absolute;
    top: 0;
    right: 0;
  }
}

.main {
  margin-top: 60px;
  height: 315px;

  .position {
    width: 270px;
    float: left;

    ul li {
      height: 45px;
      padding: 8px 20px 9px;
      background-color: #fff;
      a {
        display: inline-block;
        line-height: 28px;
        margin-left: 16px;
        text-decoration-line: none;
      }
    }

    ul li:hover {
      background-color: #26ccfc;
    }

    ul li:hover a {
      color: #fff;
    }
  }

  .advert {
    float: right;
    width: 700px;
    height: 315px;

    img {
      width: 700px;
      height: 315px;
    }
  }
}

// .footer {
//   margin-top: 50px;

//   p {
//     // font-size: 16px;
//     text-align: center;
//   }
// }
</style>
