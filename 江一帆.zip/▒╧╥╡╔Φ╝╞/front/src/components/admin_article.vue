<template>
  <div class="admin_users">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item>首页</el-breadcrumb-item>
      <el-breadcrumb-item>文章管理</el-breadcrumb-item>
      <el-breadcrumb-item>文章列表</el-breadcrumb-item>
    </el-breadcrumb>
    <el-button plain class="add" size="small" @click="updateArticleDialog = true">添加文章</el-button>
    <el-table :data="articleList" style="width: 100%">
      <el-table-column prop="title" label="标题" width="180"></el-table-column>
      <el-table-column prop="content" label="内容" width="180"></el-table-column>
      <el-table-column prop="time" label="时间" width="180"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="primary"
            icon="el-icon-edit"
            plain
            size="small"
            @click="showEditArticle(scope.row)"
          ></el-button>
          <el-button
            type="danger"
            icon="el-icon-delete"
            plain
            size="small"
            @click="delArticle(scope.row.id)"
          ></el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 修改文章对话框 -->
    <el-dialog title="修改文章" :visible.sync="addArticleDialogFormVisible">
      <el-form :model="addArticleForm" ref="addArticleForm" :rules="articleRules">
        <el-form-item label="标题" :label-width="formLabelWidth" prop="title">
          <el-input v-model="addArticleForm.title" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="内容" :label-width="formLabelWidth" prop="content">
          <el-input type="textarea" v-model="addArticleForm.content" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addArticleDialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addArticle">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 添加文章对话框 -->
    <el-dialog title="添加文章" :visible.sync="updateArticleDialog">
      <el-form :model="addArticleForm" ref="addArticleForm" :rules="articleRules">
        <el-form-item label="标题" :label-width="formLabelWidth" prop="title">
          <el-input v-model="addArticleForm.title" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="内容" :label-width="formLabelWidth" prop="content">
          <el-input type="textarea" v-model="addArticleForm.content" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="updateArticleDialog = false">取 消</el-button>
        <el-button type="primary" @click="addArticle">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      articleList: [],
      formLabelWidth: '120px',
      updateArticleDialog: false,
      addArticleDialogFormVisible: false,
      articleRules: {
        title: [{ required: true, message: '请填写标题', trigger: 'blur' }],
        content: [{ required: true, message: '请填写内容', trigger: 'blur' }]
      },
      updateArticleForm: {
        id: '',
        title: '',
        content: ''
      },
      addArticleForm: {
        title: '',
        content: ''
      }
    }
  },
  methods: {
    showArticle() {
      this.axios({
        method: 'get',
        url: 'article'
      }).then(res => {
        if (res.data.code === 200) {
          this.articleList = res.data.data
          this.articleList.forEach(item => {
            item.time = item.time.slice(0, 10)
          })
        }
      })
    },
    showEditArticle(row) {
      this.updateArticleDialog = true
      this.updateArticleForm.id = row.id
      this.updateArticleForm.title = row.title
      this.updateArticleForm.content = row.content
    },
    updateArticle() {
      this.$refs.updateArticleForm.validate(valid => {
        if (!valid) return false
        this.axios({
          method: 'post',
          url: 'updateArticle',
          data: this.updateArticleForm
        }).then(res => {
          if (res.data.code === 2) {
            this.updateArticleDialog = false
            this.$refs.updateArticleForm.resetFields()
            this.showArticle()
          }
        })
      })
    },
    delArticle(id) {
      this.$confirm('确定要删除吗？', '提示', {
        type: 'warning'
      }).then(() => {
        this.axios({
          method: 'get',
          url: 'delArticle',
          params: {
            id: id
          }
        }).then(res => {
          console.log(res.data)
          this.showArticle()
        })
      })
    },
    addArticle() {
      this.$refs.addArticleForm.validate(valid => {
        if (!valid) return false
        this.axios({
          method: 'post',
          url: 'addArticle',
          data: this.addArticleForm
        }).then(res => {
          if (res.data.code === 2) {
            this.showArticle()
            this.$refs.addArticleForm.resetFields()
            this.updateArticleDialog = false
          }
        })
      })
    }
  },
  created() {
    this.showArticle()
  }
}
</script>

<style lang="less" scoped>
/deep/.el-table .cell {
  white-space: nowrap;
  text-overflow: ellipsis;
}
.el-breadcrumb {
  height: 30px;
  line-height: 30px;
}
.add {
  margin: 5px 0;
}
</style>
