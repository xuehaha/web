<template>
  <el-container class="admin_home">
    <el-header>
      <div class="logo"></div>
      <div class="title">
        <h1>后台管理系统</h1>
      </div>
      <div class="logout">
        <a href="javascript:;" @click="logout">退出</a>
      </div>
    </el-header>
    <el-container>
      <el-aside width="200px">
        <el-menu
          default-active="1"
          class="el-menu-vertical-demo"
          @open="handleOpen"
          @close="handleClose"
          unique-opened
          router
        >
          <el-submenu index="1">
            <template slot="title">
              <i class="el-icon-location"></i>
              <span>用户管理</span>
            </template>
            <el-menu-item index="admin_users">
              <i class="el-icon-menu"></i>
              <span slot="title">用户列表</span>
            </el-menu-item>
          </el-submenu>
          <el-submenu index="2">
            <template slot="title">
              <i class="el-icon-location"></i>
              <span>文章管理</span>
            </template>
            <el-menu-item index="admin_article">
              <i class="el-icon-menu"></i>
              <span slot="title">文章列表</span>
            </el-menu-item>
          </el-submenu>
        </el-menu>
      </el-aside>
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
export default {
  methods: {
    logout() {
      this.$confirm('确定要退出吗？', '提示', {
        $confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$cookies.remove('keyname')
        this.$router.push('/login')
        this.$message.success('退出成功')
      })
    },
    handleOpen(key, keyPath) {
      console.log(key, keyPath)
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath)
    }
  }
}
</script>

<style lang="less" scoped>
.admin_home {
  height: 100%;
  .el-header {
    background: #26ccfc;
    display: flex;

    .logo,
    .logout {
      width: 180px;
    }

    .logout {
      text-align: center;
      line-height: 60px;
      text-decoration: none;
      font-size: 16px;

      a {
        color: #fff;
      }
    }

    .title {
      flex: 1;

      h1 {
        text-align: center;
        line-height: 60px;
        font-weight: normal;
        color: #fff;
      }
    }
  }

  .el-aside {
    background-color: #fff;
  }

  .el-main {
    background: #eee;
  }
}
</style>
