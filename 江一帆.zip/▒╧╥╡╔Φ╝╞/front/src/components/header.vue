<template>
  <div class="header">
    <div class="top">
      <div class="w">
        <div class="logo">
          <img src="../../static/images/logo.png" alt>
        </div>
        <div class="nav">
          <ul>
            <li>
              <router-link to="/index">首页</router-link>
            </li>
            <li>
              <router-link to="/post">职位</router-link>
            </li>
            <li>
              <router-link to="/company">公司</router-link>
            </li>
            <li>
              <router-link to="/info">资讯</router-link>
            </li>
          </ul>
        </div>
        <div class="btns" v-if="isCookie">
          <router-link to="/personal">个人中心</router-link>
          <span @click="logout">
            <router-link to="/index">退出</router-link>
          </span>
        </div>
        <div class="btns" v-else>
          <router-link to="/register">注册</router-link>
          <router-link to="/login">登录</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isCookie: false
    }
  },
  methods: {
    personShow() {
      var res = this.$cookies.get('keyname')
      if (res) {
        this.isCookie = true
      }
    },
    logout() {
      this.$confirm('确定要退出吗？', '提示', {
        $confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$cookies.remove('keyname')
        this.isCookie = false
        this.$router.push('/login')
        this.$message.success('退出成功')
      })
    }
  },
  mounted() {
    this.personShow()
  }
}
</script>

<style lang="less">
.w {
  width: 1000px;
  margin: 0 auto;
}
.header {
  width: 100%;
  height: 50px;

  .top {
    height: 50px;
    background-color: #202329;

    .logo {
      //   margin-left: 120px;
      float: left;
      margin-top: 5px;

      img {
        width: 144px;
        height: 40px;
      }
    }

    .nav {
      float: left;
      margin-left: 15px;
      line-height: 50px;

      li {
        display: inline-block;
        text-align: center;
        margin: 0 15px;

        a {
          color: #fff;
          text-decoration-line: none;
        }

        a:hover {
          color: #26ccfc;
        }
      }

      li .cur a {
        color: #26ccfc;
      }
    }

    .btns {
      float: right;
      line-height: 50px;
      margin-left: 380px;

      a {
        color: #fff;
        text-decoration-line: none;
        margin: 0 10px;
      }

      a:hover {
        color: #26ccfc;
      }
    }
  }
}
</style>
