import Vue from 'vue'
import App from './App'
import router from './router'
import VueCookies from 'vue-cookies'
import axios from 'axios'
// 导入elementui
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

// 导入样式
import '@/assets/base.less'

Vue.use(ElementUI)
Vue.use(VueCookies)

Vue.prototype.axios = axios
axios.defaults.baseURL = 'http://localhost:3000/'

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  render: h => h(App)
})
