import Vue from 'vue'
import Router from 'vue-router'
import Login from 'components/Login'
import Register from 'components/register.vue'
import Index from 'components/index.vue'
import Post from 'components/post.vue'
import Company from 'components/company.vue'
import Info from 'components/info.vue'
import Personal from 'components/personal.vue'
import JobDetail from 'components/job_detail.vue'
import CompanyDetail from 'components/company_detail.vue'
import Article from 'components/article.vue'
import AdminHome from 'components/admin_home.vue'
import AdminUsers from 'components/admin_users.vue'
import AdminArticle from 'components/admin_article.vue'

Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/',
      redirect: '/index'
    },
    {
      path: '/login',
      component: Login
    },
    {
      path: '/register',
      component: Register
    },
    {
      path: '/index',
      component: Index
    },
    {
      path: '/post',
      component: Post
    },
    {
      path: '/company',
      component: Company
    },
    {
      path: '/info',
      component: Info
    },
    {
      path: '/personal',
      component: Personal
    },
    {
      path: '/job_detail',
      component: JobDetail
    },
    {
      path: '/company_detail',
      component: CompanyDetail
    },
    {
      path: '/article',
      component: Article
    },

    {
      path: '/admin_home',
      component: AdminHome,
      children: [
        {
          path: '/admin_users',
          component: AdminUsers
        },
        {
          path: '/admin_article',
          component: AdminArticle
        }
      ]
    }
  ]
})

router.beforeEach((to, from, next) => {
  let cookie = router.app.$cookies.get('keyname')
  if (to.path === '/personal') {
    if (cookie) {
      next()
    } else {
      next('/login')
    }
  } else if (to.path === '/admin_home') {
    if (cookie) {
      next()
    } else {
      next('/login')
    }
  } else if (to.path === '/admin_users') {
    if (cookie) {
      next()
    } else {
      next('/login')
    }
  } else {
    next()
  }
})

export default router
