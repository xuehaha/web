/*
Navicat MySQL Data Transfer

Source Server         : MySQL
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : zhaopin

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-04-15 02:38:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for article
-- ----------------------------
DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of article
-- ----------------------------
INSERT INTO `article` VALUES ('1', '这是新闻标题', '本报告由大学生招聘和网易有道词典联合发布，如需转载请移步BOSS直聘微信公号（ID：bosszhipin）申请转载。', '2019-04-15 01:35:47');

-- ----------------------------
-- Table structure for companydetail
-- ----------------------------
DROP TABLE IF EXISTS `companydetail`;
CREATE TABLE `companydetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `companytxt` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of companydetail
-- ----------------------------
INSERT INTO `companydetail` VALUES ('1', '今日头条是北京字节跳动科技有限公司开发的一款基于数据挖掘的推荐引擎产品，为用户推荐信息，提供连接人与信息的服务的产品。由张一鸣于2012年3月创建，2012年8月发布第一个版本。 [1] \r\n2016年9月20日，今日头条宣布投资10亿元用以补贴短视频创作。后独立孵化 UGC 短视频平台火山小视频 [2] 。2017年1月，今日头条中国新第一批认证的8组独立音乐人入驻今日头条。2017年2月2日，全资收购美国短视频应用Flipagram', '1');

-- ----------------------------
-- Table structure for companylist
-- ----------------------------
DROP TABLE IF EXISTS `companylist`;
CREATE TABLE `companylist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comname` varchar(255) NOT NULL,
  `comtype` varchar(255) NOT NULL,
  `comregion` varchar(255) NOT NULL,
  `comlogo` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `comstatus` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of companylist
-- ----------------------------
INSERT INTO `companylist` VALUES ('1', '蚂蚁金服', '互联网', '洛阳 洛龙区', '/static/images/company_logo_mayi.jpg', '1000人以上', 'C轮', '2');
INSERT INTO `companylist` VALUES ('2', '携程旅行', '互联网', '洛阳 洛龙区', '/static/images/company_logo_xiecheng.jpg', '10000人以上', '已上市', '3');
INSERT INTO `companylist` VALUES ('3', '今日头条', '移动互联网', '洛阳 洛龙区', '/static/images/company_logo_jinri.jpg', '1000-9999人', '不需要融资', '4');
INSERT INTO `companylist` VALUES ('4', '德邦快递', '物流/仓储', '洛阳 洛龙区', '/static/images/company_logo_debang.jpg', '1000人以上', '已上市', '5');
INSERT INTO `companylist` VALUES ('5', '哈啰出行', '互联网', '洛阳 洛龙区', '/static/images/company_logo_haluo.jpg', '1000-9999人', 'D轮及以上', '6');
INSERT INTO `companylist` VALUES ('6', '掌门1对1', '互联网', '洛阳 洛龙区', '/static/images/company_logo_zhangmen.jpg', '1000人以上', 'D轮及以上', '7');
INSERT INTO `companylist` VALUES ('7', '海风教育', '在线教育', '洛阳 洛龙区', '/static/images/company_logo_haifeng.jpg', '1000人以上', 'D轮及以上', '8');
INSERT INTO `companylist` VALUES ('8', '平安惠普', 'O2O', '洛阳 洛龙区', '/static/images/company_logo_pingan.jpg', '20-99人', '未融资', '9');

-- ----------------------------
-- Table structure for jobclass
-- ----------------------------
DROP TABLE IF EXISTS `jobclass`;
CREATE TABLE `jobclass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `sort_1` varchar(255) DEFAULT NULL,
  `sort_2` varchar(255) DEFAULT NULL,
  `sort_3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jobclass
-- ----------------------------
INSERT INTO `jobclass` VALUES ('1', '技术', 'Java', 'PHP', 'web前端');
INSERT INTO `jobclass` VALUES ('2', '产品', '产品经理', '产品专员', null);
INSERT INTO `jobclass` VALUES ('3', '设计', 'UI设计师', '平面设计师', null);
INSERT INTO `jobclass` VALUES ('4', '运营', '新媒体运营', '产品运营', null);
INSERT INTO `jobclass` VALUES ('5', '市场', '市场营销', '市场推广', null);
INSERT INTO `jobclass` VALUES ('6', '人事', 'HR', '行政', '财务');
INSERT INTO `jobclass` VALUES ('7', '媒体', '文案', '广告创意', '编辑');

-- ----------------------------
-- Table structure for message
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `xm` varchar(255) NOT NULL,
  `xl` varchar(255) NOT NULL,
  `zw` varchar(255) NOT NULL,
  `sj` varchar(255) NOT NULL,
  `yx` varchar(255) NOT NULL,
  `jj` varchar(255) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO `message` VALUES ('9', '张三三', '本科', 'web前端', '18903881044', '714347650@qq.com', '1、精通前端开发技术（html/css/ES6 /TypeScriptdeJs），具备跨终端（ Mobile+PC ）的前端开发能力和移动端原生开发，熟悉网络协议（ HTTP/SSL ）；\r\n2、具有前端工程化与模块化的开发技术和工具，并有实践经验（如 gulp/webpack等）；\r\n3、具有vue，react开发经验，并了解框架运行原理以及性能优化；\r\n4、熟悉各种浏览器平台的特性，能够很好地解决兼容问题和疑难问题；', '1', '2');

-- ----------------------------
-- Table structure for postdetail
-- ----------------------------
DROP TABLE IF EXISTS `postdetail`;
CREATE TABLE `postdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `posttxt` text NOT NULL,
  `post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of postdetail
-- ----------------------------
INSERT INTO `postdetail` VALUES ('1', '1. 移动端 Web 开发经验。 \r\n2. 丰富的 处理移动端浏览器兼容性的经验。 \r\n3. 精通HTML5/CSS3/ECMAScrip≥2017 等技术。 \r\n4. 精通Vue.js/React.js 框架，深谙Vuex、Redux等模式。 \r\n5. 精通webpack等基于Node.js的开发工具，有Node.js项目开发经验 ，了解敏捷开发流程相关概念 ，了解交互设计相关技巧 ，\r\n6.有移动端APP项目开发经验', '1');
INSERT INTO `postdetail` VALUES ('2', '1. 3年以上大型数据库如mysql使用经验，3年以上大规模高并发访问的Web应用开发经验；\r\n2. 扎实的java编程基础，对各种开源的框架如Spring、SpringMVC、MyBatis等有深入的了解，对SOA、OSGI有深入了解并实践者优先考虑； \r\n3. 熟练掌握unix/linux操作系统，对常用命令运用娴熟，能够根据实际需要编写shell脚本； \r\n4. 较强的表达和沟通能力；\r\n5. 工作认真、严谨、敬业，对系统质量有严格要求的意识', '2');
INSERT INTO `postdetail` VALUES ('4', '1. 3年以上PHP前端程序开发经验； 了解php运行机制,熟练使用PHP开发语言；掌握html,div，css,js,熟练使用jquery,能够独立完成前端页面制作及开发； 2. 熟悉Mysql、apache/Nginx架构、模板引擎、中间件的原理与应用； 3. 熟悉常用的框架Yii、ThinkPHP等； 4. 具备良好的编码规范和编程习惯，要求结构清晰、命名规范、逻辑性强、代码冗余率低，代码注释清晰。', '8');

-- ----------------------------
-- Table structure for postlist
-- ----------------------------
DROP TABLE IF EXISTS `postlist`;
CREATE TABLE `postlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `posname` varchar(255) NOT NULL,
  `pospay` varchar(255) NOT NULL,
  `posregion` varchar(255) NOT NULL,
  `poseducation` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of postlist
-- ----------------------------
INSERT INTO `postlist` VALUES ('1', '前端开发工程师', '12k-18k', '洛阳 伊滨区', '本科', '1', '2');
INSERT INTO `postlist` VALUES ('2', 'Java开发工程师', '7k-12k', '洛阳 洛龙区', '大专', '2', '3');
INSERT INTO `postlist` VALUES ('8', 'PHP工程师', '7k-9k', '洛阳 西工区', '本科', '1', '2');

-- ----------------------------
-- Table structure for resume
-- ----------------------------
DROP TABLE IF EXISTS `resume`;
CREATE TABLE `resume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `xingming` varchar(255) NOT NULL,
  `xueli` varchar(255) NOT NULL,
  `zhiwei` varchar(255) NOT NULL,
  `jianjie` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of resume
-- ----------------------------
INSERT INTO `resume` VALUES ('1', '张三三', '本科', 'web前端', '1、精通前端开发技术（html/css/ES6 /TypeScriptdeJs），具备跨终端（ Mobile+PC ）的前端开发能力和移动端原生开发，熟悉网络协议（ HTTP/SSL ）；\r\n2、具有前端工程化与模块化的开发技术和工具，并有实践经验（如 gulp/webpack等）；\r\n3、具有vue，react开发经验，并了解框架运行原理以及性能优化；\r\n4、熟悉各种浏览器平台的特性，能够很好地解决兼容问题和疑难问题；', '1');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `identity` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('2', 'mayi', '123456', '2', '13679849531', '123456789@qq.com', '王先生');
INSERT INTO `users` VALUES ('1', 'aaa', '123456', '1', '18903881044', '714347650@qq.com', '张三');
INSERT INTO `users` VALUES ('3', 'xiecheng', '123456', '2', '17543859270', 'abcd@163.com', '刘女士');
INSERT INTO `users` VALUES ('4', 'jinri', '123456', '2', null, null, null);
INSERT INTO `users` VALUES ('5', 'debang', '123456', '2', null, null, null);
INSERT INTO `users` VALUES ('6', 'haluo', '123456', '2', null, null, null);
INSERT INTO `users` VALUES ('7', 'zhangmen', '123456', '2', null, null, null);
INSERT INTO `users` VALUES ('8', 'haifeng', '123456', '2', null, null, null);
INSERT INTO `users` VALUES ('9', 'pingan', '123456', '2', null, null, null);
INSERT INTO `users` VALUES ('104', 'admin', '123456', '0', null, null, null);
